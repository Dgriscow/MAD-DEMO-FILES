import UIKit

var str = "Func 6 Step Program"

func doAnything(whatiLike: String) -> String {
    let myfavorite = "I really like, " + whatiLike + "!"
    return myfavorite
}

print(doAnything(whatiLike: "Corn"))
